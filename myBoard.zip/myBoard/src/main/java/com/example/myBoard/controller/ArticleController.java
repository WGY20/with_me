package com.example.myBoard.controller;

import com.example.myBoard.dto.ArticleDto;
import com.example.myBoard.entity.Article;
import com.example.myBoard.service.ArticleService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
@RequestMapping("/articles")
public class ArticleController {

    private final ArticleService articleService;

    public ArticleController(ArticleService articleService) {
        this.articleService = articleService;
    }


    //    새로운 값 추가
    @GetMapping("/insert")
    public String insertView(ArticleDto articleDto,
                             Model model) {
        model.addAttribute("articleDto", articleDto);
        return "/articles/insert";
    }

    @PostMapping("/insert")
    public String insertNew(@ModelAttribute("articleDto") ArticleDto articleDto) {
        articleService.insertArticle(articleDto);
        return "redirect:/";
    }


    //    삭제
    @PostMapping("/delete/{deleteId}")
    public String deleteArticle(@PathVariable("deleteId") Long id,
                                RedirectAttributes redirectAttributes) {
//        1. 삭제할 값이 있는지 확인
//        ArticleDto articleDto = articleService.findById(id);
//        2. 대상 엔티티가 존재하면 삭제 처리 후 메세지를 전송
//        if (articleDto != null) {
//            articleService.deleteById(id);
//        redirectAttributes.addFlashAttribute("msg", "정상적으로 삭제 완료");
//        }
        articleService.delete(id);
        return "redirect:/";
    }


    //    수정
    @GetMapping("/update")
    public String updateForm(ArticleDto articleDto, Model model) {
        model.addAttribute("articleDto", articleDto);
        return "articles/update";
    }

    @PostMapping("/update/{updateId}")
    public String updateArticle(@ModelAttribute("articleDto") ArticleDto articleDto) {
        articleService.updateArticle(articleDto);
        return "redirect:/";
    }

    @GetMapping("/detail/{id}")
    public String detailView(@ModelAttribute("id") Long id,
                             Model model) {
        ArticleDto articleDto = articleService.showOneArticle(id);
        return "articles/detail";
    }

}
