package com.example.myBoard.service;

import com.example.myBoard.dto.ArticleDto;
import com.example.myBoard.entity.Article;
import com.example.myBoard.repository.ArticleRepository;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class ArticleService {
    private final ArticleRepository articleRepository;

    public ArticleService(ArticleRepository articleRepository) {
        this.articleRepository = articleRepository;
    }

    public List<ArticleDto> showAllArticles() {
        List<ArticleDto> articleDtoList = new ArrayList<>();
        return articleRepository.findAll()
                .stream()
                .map(x -> ArticleDto.fromArticleEntity(x))
                .toList();
    }

    public ArticleDto showOneArticle(Long id) {
        Article article = articleRepository.findById(id).orElse(null);
        if (article == null) {
            return null;
        } else {
            return ArticleDto.fromArticleEntity(article);
        }
    }

    public void insertArticle(ArticleDto articleDto) {
        Article article = articleDto.fromArticleDto(articleDto);
        articleRepository.save(article);
    }


    public void delete(Long id) {
        articleRepository.deleteById(id);
    }

    public void updateArticle(ArticleDto articleDto) {
        Article article = articleDto.fromArticleDto(articleDto);
//        Article article1 = Article.builder()
//                .title(articleDto.getTitle())
//                .content(articleDto.getContent())
//                .build(); --> builder를 이용한 값 가져오기
        articleRepository.save(article);
    }
}



