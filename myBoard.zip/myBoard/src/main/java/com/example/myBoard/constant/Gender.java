package com.example.myBoard.constant;

public enum Gender {
    Male,
    Female
}
