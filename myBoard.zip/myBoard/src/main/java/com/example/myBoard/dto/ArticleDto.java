package com.example.myBoard.dto;

import com.example.myBoard.entity.Article;
import lombok.*;

@Data
@AllArgsConstructor
@NoArgsConstructor
@ToString
@Builder
public class ArticleDto {

    private Long id;
    private String title;
    private String content;


//    Entity를 Dto로 변환
    public static ArticleDto fromArticleEntity(Article article) {
        return new ArticleDto(
                article.getId(),
                article.getTitle(),
                article.getContent()
        );
    }

    //    Dto를 Entity로 변환
    public Article fromArticleDto(ArticleDto articleDto) {
        Article article = new Article();
        article.setId(articleDto.getId());
        article.setTitle(articleDto.getTitle());
        article.setContent(articleDto.getContent());
        return article;
    }
}
