package com.example.myBoard.service;

import com.example.myBoard.dto.ArticleDto;
import jakarta.transaction.Transactional;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.TestPropertySource;

import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest
@Transactional
@TestPropertySource(locations = "classpath:application-test.properties")
class ArticleServiceTest {

    @Autowired
    ArticleService articleService;

    @Test
    @DisplayName("전체데이터_읽기")
    void showAllArticles() {
//        Given
        int totalCount = 3;
//        When
        List<ArticleDto> list = articleService.showAllArticles();
        int actualCount = list.size();
//        Then
        org.assertj.core.api.Assertions.assertThat(actualCount).isEqualTo(totalCount);
    }

//    @Test
//    @DisplayName("자료입력_테스트")
//    void insertData() {
//        // Given
//        ArticleDto expectDto = ArticleDto.builder()
//                .id(4L)
//                .title("라라라")
//                .content("444")
//                .build();
//
//        // When
//        articleService.insertArticle(ArticleDto.builder()
//                .title("라라라")
//                .content("444")
//                .build());
//
//        // Then
//        insertData(articleService.showOneArticle(4L).getTitle()).isEqualTo("라라라");
//        insertData(articleService.showOneArticle(4L).getContent()).isEqualTo("444");
//    }


    @Test
    void delete() {
//        Given
        Long deleteId = 2L;
//        When
        articleService.delete(deleteId);
//        Then
        ArticleDto articleDto = articleService.showOneArticle(deleteId);
        assertThat(articleDto).isEqualTo(null);
    }

    @Test
    void updateArticle() {
//        Given
        ArticleDto expectDto = new ArticleDto(2L, "두두두", "222");
//        When
        articleService.updateArticle(new ArticleDto(2L, "두두두", "222"));
        ArticleDto resultDto = articleService.showOneArticle(2L);
//        Then
        assertThat(resultDto.toString()).isEqualTo(expectDto.toString());
    }
}