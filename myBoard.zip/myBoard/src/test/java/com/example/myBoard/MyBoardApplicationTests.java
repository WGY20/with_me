package com.example.myBoard;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MyBoardApplicationTests {

	@Test
	void contextLoads() {
	}

}
