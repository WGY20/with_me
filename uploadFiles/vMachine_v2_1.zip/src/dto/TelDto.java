package dto;

public record TelDto(       // 프로세스 간에 데이터를 전달하는 역할
        int id,
        String name,
        int age,
        String addr,
        String tel) {
    public static TelDto allOf(int id, String name, int age, String addr, String tel){
        return new TelDto(id, name, age, addr, tel);
    }

    @Override
    public String toString() {
        return
                "id=" + id +
                ", name= " + name +
                ", age=" + age +
                ", addr=" + addr +
                ", tel=" + tel;
    }

    //    아이디가 빠진 애를 위함
    public TelDto(String name, int age, String addr, String tel) {
        this(0, name, age, addr, tel);
    } // of는 4개의 인자를 가지기 때문에 4개인 생성자 생성한 것

    public static TelDto of(String name, int age, String addr, String tel){
        return new TelDto(name, age, addr, tel);
    }
}
