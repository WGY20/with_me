import db.DBConn;
import service.UserService;
import view.UserView;

import java.util.Scanner;

public class TelAppMain {
    public static void main(String[] args) {
    UserView userView = new UserView();
        Scanner sc = new Scanner(System.in);
        int choice; // 스캐너로 받을 변수

        do {
            System.out.println("1.입력 2.수정 3.삭제 4.전체데이터 5.한개만 6.종료");
            choice = sc.nextInt();
        } while (choice<0 || choice>6);

        while (true){
            switch (choice){
                case 1:
                    userView.insertView(); //유저뷰에 insertView 만들기
                    break;
                case 2:
                    userView.updateView();
                    break;
                case 3:
                    userView.deleteView();
                    break;
                case 4:
                    userView.showAllView();
                    break;
                case 5:
                    userView.showOneView();
                    break;
                case 6:
                    DBConn.close();     // 종료하니까 DB 완전히 끊어버리기
                    return;      // 종료
            }
        }
    }
}