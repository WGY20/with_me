package service;

import db.DBConn;
import dto.TelDto;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class UserService {
    public int insertData(TelDto dto) {
        Connection conn = DBConn.getConnection();
        PreparedStatement psmt = null;
        int result = 0;
        String query;       // 쿼리를 담을 공간
        try {
            query = "insert into telbook(name, age, addr, tel) " + "values(?, ?, ?, ?)"; // 쿼리 만들기
            psmt = conn.prepareStatement(query);
//            위 물음표에 뭐가 들어가는지 알려주기
            psmt.setString(1, dto.name());
            psmt.setInt(2, dto.age());
            psmt.setString(3, dto.addr());
            psmt.setString(4, dto.tel());
            result = psmt.executeUpdate();  // 사용자에게 저장 확인 정보를 출력해주기 위해 result 만든 것
            psmt.close();       // psmt 문 닫기
            return result;
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        } return result;        // 제대로 입력이 되면 return이 되고 실패하면 catch로 간다
    }

    public TelDto selectOne(int id) {
        Connection conn = DBConn.getConnection();
        PreparedStatement psmt = null;
        ResultSet rs = null;
        TelDto dto = null;             // dto에 보내기 위해 선언
        try {
            String query = "select * from telbook where id=?";
            psmt = conn.prepareStatement(query);
            psmt.setInt(1, id);     // 위에 물음표 값을 알려주기
            rs = psmt.executeQuery();
            while (rs.next()) {      // 가져갈 dto 만들기
                dto = TelDto.allOf(
                        rs.getInt("id"),
                        rs.getString("name"),
                        rs.getInt("age"),
                        rs.getString("addr"),
                        rs.getString("tel")
                );
            }
            psmt.close();       // 문 닫기
            rs.close();         // 문 닫기
            return dto;
        } catch (SQLException e) {
            System.out.println();
        } return dto;
    }

    public int updateData(TelDto dto) {
        Connection conn = DBConn.getConnection();       // DB 연결하기
        PreparedStatement psmt = null;
        int result = 0;
        try {
            String query = "update telbook set name =? , age =?, addr=?, tel=?" + "where id=?";
            psmt = conn.prepareStatement(query);        // psmt에 쿼리 집어넣어 주기
            psmt.setString(1, dto.name());
            psmt.setInt(2, dto.age());
            psmt.setString(3, dto.addr());
            psmt.setString(4, dto.tel());
            psmt.setInt(5, dto.id());
            result =  psmt.executeUpdate();
            psmt.close();
            return result;
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        } return result;
    }


    public int deleteData(int id) {
        Connection conn = DBConn.getConnection();       // DB 연결하기
        PreparedStatement psmt = null;
        int result = 0;
        String query = null;
        try {
            query = "delete from telbook where id=?";
            psmt = conn.prepareStatement(query);
            psmt.setInt(1, id);     // 위에 물음표 값을 알려주기
            result = psmt.executeUpdate();
            psmt.close();       // 문 닫기
            return result;
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        } return result;
    }

    public List<TelDto> showAllData() {
        Connection conn = DBConn.getConnection();
        List<TelDto> list = new ArrayList<>();
        TelDto dto = null;
        PreparedStatement psmt = null;
        ResultSet rs = null;
        String query = null;
        try {
            query = "select * from telbook order by id";
            psmt = conn.prepareStatement(query);
            rs = psmt.executeQuery();
            while (rs.next()){
                dto = TelDto.allOf(
                        rs.getInt("id"),
                        rs.getString("name"),
                        rs.getInt("age"),
                        rs.getString("addr"),
                        rs.getString("tel")
                );
                list.add(dto);
            }
            psmt.close();
            rs.close();
            return list;
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }return list;
    }
}
