package com.example.basiccrud.entity;

import jakarta.persistence.*;
import lombok.Data;
import org.springframework.context.annotation.Primary;

@Entity
@Data
public class Member {

    @Id     // PK
    @GeneratedValue(strategy = GenerationType.AUTO)     // Auto-increment
    @Column
    private Long id;

    @Column(length = 20, nullable = false)
    private String name;

    private int age;

    @Column(name = "address", length = 200)
    private String addr;
}
