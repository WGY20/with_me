package com.example.demoApp.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class DemoController {
    @GetMapping("/hi")
    public String hi(Model model){
        model.addAttribute("name", "장원영");
        return "ok";        // 하이페이지로 들어가면 ok페이지를 보여줘
    }
}
