package view;

import init.InitClass;
import java.util.Scanner;
import service.AdminService;

public class AdminView {
    Scanner sc;
    AdminService adminService;

    public AdminView() {
        this.sc = new Scanner(System.in);
        this.adminService = new AdminService();
    }

    public void adminView() {
        while(true) {
            InitClass.line();
            System.out.println("관리자 페이지입니다.");
            System.out.println("1:메뉴변경 2:가격변경 3:재고추가 4:메뉴추가 5:수익확인(종료는 -1)");
            System.out.print("번호를 입력하세요:");
            int num = this.sc.nextInt();
            InitClass.line();
            if (num == 1) {
                this.adminService.updateMenu();
            } else if (num == 2) {
                this.adminService.updatePrice();
            } else if (num == 3) {
                this.adminService.updateStock();
            } else if (num == 4) {
                if (InitClass.productCount == 4) {
                    System.out.println("더 이상 메뉴가 들어갈 자리가 없습니다!");
                } else {
                    this.adminService.addMenu();
                }
            } else if (num == 5) {
                this.adminService.confirmProfit();
            } else if (num == -1) {
                return;
            }
        }
    }
}
