package view;

import init.InitClass;
import java.util.Scanner;
import service.UserService;

public class UserView {
    Scanner sc;
    UserService userService;
    AdminView adminView;
    public static int money = 0;

    public UserView() {
        this.sc = new Scanner(System.in);
        this.userService = new UserService();
        this.adminView = new AdminView();
    }

    public void userView() {
        Boolean first = true;

        while(true) {
            while(true) {
                InitClass.line();
                this.userService.menuView();
                InitClass.line();
                if (first) {
                    System.out.print("돈을 넣어주세요:");
                    money = this.sc.nextInt();
                    first = false;
                }

                if (money == 1004) {
                    this.adminView.adminView();
                    this.userService.menuView();
                }

                System.out.print("메뉴입력:");
                int num = this.sc.nextInt();
                if (money >= InitClass.price[num - 1]) {
                    if (InitClass.stock[num - 1] <= 0) {
                        System.out.println("현재 재고가 없습니다!");
                        continue;
                    }

                    this.userService.outProduct(num - 1);
                } else {
                    System.out.println("잔액이 부족합니다!");
                }

                System.out.println("잔액:" + money);
                if (money == 0) {
                    System.out.println("감사합니다! 다음에 또 이용해 주세요!!");
                    first = true;
                } else {
                    System.out.println("1:계속구매하기 2:금액추가하기 3:잔돈반환하기");
                    System.out.print("번호를 입력하세요:");
                    int num1 = this.sc.nextInt();
                    if (num1 != 1) {
                        if (num1 == 2) {
                            this.userService.addMoney();
                        } else if (num1 == 3) {
                            this.userService.returnMoney();
                            first = true;
                        }
                    }
                }
            }
        }
    }
}