package service;

import init.InitClass;
import java.util.Scanner;
import view.UserView;

public class UserService {
    Scanner sc;

    public UserService() {
        this.sc = new Scanner(System.in);
    }

    public void menuView() {
        System.out.println("자판기입니다.(번호:상품(가격)-재고)");

        for(int i = 0; i < 5; ++i) {
            if (InitClass.product[i] != null) {
                System.out.print(i + 1 + ":" + InitClass.product[i] + "(" + InitClass.price[i] + "W)-" + InitClass.stock[i] + "개 ");
                InitClass.productCount = i;
            }
        }

        System.out.println();
    }

    public void outProduct(int num) {
        UserView.money -= InitClass.price[num];
        int var10002 = InitClass.stock[num]--;
        InitClass.profit += InitClass.price[num];
        String var10001 = InitClass.product[num];
        System.out.println(var10001 + "이(가) 나왔다!");
    }

    public void addMoney() {
        System.out.print("돈을 넣어주세요:");
        int extra = this.sc.nextInt();
        UserView.money += extra;
        System.out.println("금액이 추가 되었습니다! 잔액:" + UserView.money);
    }

    public void returnMoney() {
        System.out.println("거스름 돈" + UserView.money + "원이 반환 됩니다.");
        System.out.println("감사합니다! 다음에 또 이용해주세요!!");
    }
}


