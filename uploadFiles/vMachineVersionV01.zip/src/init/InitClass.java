package init;

public class InitClass {
    public static final int MAX = 5;
    public static String[] product = new String[5];
    public static int[] price = new int[5];
    public static int[] stock = new int[5];
    public static int currentMoney = 0;
    public static int profit = 0;
    public static int productCount = 3;

    public InitClass() {
    }

    public static void initialize() {
        product[0] = "콜라";
        price[0] = 500;
        stock[0] = 3;
        product[1] = "사이다";
        price[1] = 700;
        stock[1] = 4;
        product[2] = "커피";
        price[2] = 1500;
        stock[2] = 5;
    }

    public static void line() {
        System.out.println("=================================================");
    }
}
