package view;

import dto.ProductDto;
import dto.UserDto;
import excetion.InputValidation;
import excetion.MyException;
import service.ProductService;
import service.UserService;

import java.util.Scanner;

public class UserView {
    Scanner sc = new Scanner(System.in);
    UserService userService = new UserService();
    ProductView productView = new ProductView();
    ProductService productService = new ProductService();
    InputValidation validation = new InputValidation();
    ManagerView managerView = new ManagerView();

    public static int insertMoney;      // 넣은 금액 지역변수



//    로그인
    public boolean loginView() {
        System.out.println("아이디를 입력하세요! ");
        String id = sc.next();
        UserDto dto = userService.selectID(id);

//        관리자 페이지 연결
        if (id.equals("root")){
            System.out.println("비밀번호를 입력하세요");
            int pw = sc.nextInt();
            if (pw == 1111){
                managerView.managerMenu();
            }
        }


        if (dto == null) {
            System.out.println("아이디 정보를 찾을 수 없어요. \n 다시 입력하여주세요 \n");
        } else {
            System.out.println("해당 아이디의 비밀번호를 입력하세요.");
            String password = sc.next();
            boolean isLoginSuccess = userService.login(id, password);
            if (isLoginSuccess) {
                System.out.println("로그인 성공!");
                System.out.println("------------------------------");
                return isLoginSuccess;
            } else {
                System.out.println("비밀번호가 틀렸습니다. 다시 입력해주세요.");
                return isLoginSuccess;
            }
        }
        return false;
    }


//    회원가입
    public void signInView() throws Exception {
        String id = null;
        String pw = null;
        String userName = null;
        String telNum = null;

//        아이디 입력
        System.out.println("회원가입 페이지입니다. \n 아이디를 입력하세요!");
        id = sc.next();

//        비밀번호 입력
        System.out.println("비밀번호를 입력하세요!");
        pw = sc.next();

//        유저 이름 입력
        boolean checkName = true;
        do {
            try {
                System.out.println("이름을 입력하세요!");
                userName = sc.next();
                validation.nameCheck(userName);
                checkName = false;
            } catch (MyException e) {
                System.out.println(e.toString());
            }
        } while (checkName);

//        전화번호 입력
        boolean checkTel = true;
        do {
            try {
                System.out.println("전화번호를 입력하세요");
                telNum = sc.next();
                validation.phoneCheck(telNum);
                checkTel = false;
            } catch (MyException e) {
                System.out.println(e.toString());
            }
        } while (checkTel);

//        입력한 데이터들을 데이터베이스에 저장하는 메서드 호출
        int result = userService.createID(UserDto.commOf(id, pw, userName, telNum));
        if (result != 0) {
            System.out.println("회원가입이 되었습니다!");
            System.out.println("=====가입정보=====");
        }
    }


//    사용자 선택 메뉴
    public void choiceView() {
        System.out.println("원하시는 메뉴를 선택해주세요");
        System.out.println("(1) 제품 구매 / (2) 카드 충전 / (3) 내 정보 / (4) 로그아웃");
        int choice = sc.nextInt();
        switch (choice){
            case 1:
                buyProduct();
                choiceView();
                break;

            case 2:
                plusMoney();
                choiceView();
                break;

            case 3:
                getInfo();
                choiceView();

            case 4:     // 로그아웃
                return;
        }
    }

//    상품 구매 가능 사용자 잔액 O
    public void buyProduct(){
        productView.allProduct();
        System.out.println("현재 " + userService.currentMoney() + "원을 보유하고 있습니다");     // 회원 현재 잔액 출력
        System.out.println("구매하실 상품의 번호를 입력하여 주세요.");
        int pd = sc.nextInt();

        productService.discountStock(pd);       // product_price 수량 차감
        userService.discountMoney(pd);          // user_money 현금 차감
        productService.buyProduct(UserService.userNo, pd);    // sales 테이블 생성
        System.out.println(pd + "번 상품이 구매 되었습니다.");
        System.out.println("------------------------------------------------------------");
    }

//    상품 구매 불가 사용자 잔액 X






//    카드 충전
    public void plusMoney(){
        boolean plusMoney = true;
        do {
            try {
                System.out.println("현재 " + userService.currentMoney() + "원을 보유하고 있습니다");
                System.out.println("충전할 금액을 입력하세요");
                insertMoney = sc.nextInt();
                validation.plusMoneyCheck(insertMoney);
                plusMoney = false;
            } catch (MyException e) {
                System.out.println(e.toString());
            }
        } while (plusMoney);

        userService.plusMoney(insertMoney, UserService.userNo);
        System.out.println(insertMoney + "원 충전 완료 현재 잔액: " + userService.currentMoney() + "원");
        System.out.println("-----------------------------------------------------");
    }

//    회원 정보 출력
    public void getInfo(){
        userService.userInfo(UserService.userNo);
        UserDto dto = null;
        dto = userService.userInfo(UserService.userNo);
        System.out.println("내 정보: " + dto.toString());
        System.out.println("-----------------------------------------------------");
    }

}
