package view;

public class SalesView {
}
