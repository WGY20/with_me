package view;

import dto.ProductDto;
import service.ProductService;
import service.UserService;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class ProductView {
    ProductService productService = new ProductService();
    UserService userService = new UserService();
    Scanner sc = new Scanner(System.in);


//    판매중인 제품 출력하기
    public void allProduct() {
        System.out.println("============현재 판매 상품==============");
        List<ProductDto> dtoList = new ArrayList<>();
        dtoList = productService.getListAll();

        if (dtoList == null){
            System.out.println("판매중인 상품이 없습니다");
        } else {
            for (ProductDto dto : dtoList){
                System.out.println(dto);
                System.out.println("--------------------------------");
            }
            System.out.println("======================================");
        }
    }


}

