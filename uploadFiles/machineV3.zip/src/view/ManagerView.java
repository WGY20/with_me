package view;

import dto.UserDto;
import excetion.InputValidation;
import excetion.MyException;
import service.ManagerService;

import java.util.Scanner;

public class ManagerView {
    Scanner sc = new Scanner(System.in);
    ManagerService managerService = new ManagerService();
    InputValidation validation = new InputValidation();

    public void managerMenu() {
        int choice = 0;
        do {
            System.out.println("[관리자 메뉴]");
            System.out.println("(1) 자판기관리 / (2) 회원관리 / (3) 판매관리 / (4) 이전");
            choice = sc.nextInt();
        } while (choice < 1 || choice > 4);
        switch (choice) {
            case 1:
                machineManage();

                break;

            case 2:
                userInfo();
                break;
            case 3:
                System.out.println("판매관리 페이지입니다");
                salesManage();
                break;
            case 4:
                return;
        }
    }



    //         자판기 관리 페이지
//        자판기 관리 : 관리자는 자판기 입력, 수정, 삭제, 조회가 가능합니다.
    private void machineManage() {
        System.out.println("자판기 관리 페이지입니다.");
        System.out.println("(1) 메뉴 입력 (2) 메뉴 수정 (3) 메뉴 삭제 (4) 메뉴 조회 (5) 이전");
        int choice = sc.nextInt();
        switch (choice) {
            case 1:
                System.out.println("메뉴 입력 페이지입니다.");
                break;

            case 2:
                System.out.println("메뉴 수정 페이지입니다.");
                break;

            case 3:
                System.out.println("메뉴 삭제 페이지입니다.");
                break;

            case 4:
                System.out.println("메뉴 조회 페이지입니다.");
                break;

            case 5:
                return;
        }
    }




//        회원관리 페이지
//        회원관리 : 관리자는 회원 정보의 입력, 수정, 삭제, 조회가 가능합니다.
    public void userInfo() {
        System.out.println("회원관리 페이지입니다.");
        System.out.println("(1) 회원정보 입력 (2) 회원정보 수정 (3) 회원정보 삭제 (4) 회원정보 조회 (5) 이전");
        int choice = sc.nextInt();
        switch (choice) {
            case 1:
                System.out.println("회원정보 입력 페이지입니다");
                String id = null;
                String pw = null;
                String userName = null;
                String telNum = null;

                //        아이디 입력
                System.out.println("새로 만들 회원의 아이디를 입력하세요!");
                id = sc.next();

//                  비밀번호 입력
                System.out.println("새로 만들 회원의 비밀번호를 입력하세요!");
                pw = sc.next();

                //        유저 이름 입력
                boolean checkName = true;
                do {
                    try {
                        System.out.println("새로 만들 회원의 이름을 입력하세요!");
                        userName = sc.next();
                        validation.nameCheck(userName);
                        checkName = false;
                    } catch (MyException e) {
                        System.out.println(e.toString());
                    }
                } while (checkName);

                //        전화번호 입력
                boolean checkTel = true;
                do {
                    try {
                        System.out.println("새로 만들 회원의 전화번호를 입력하세요");
                        telNum = sc.next();
                        validation.phoneCheck(telNum);
                        checkTel = false;
                    } catch (MyException e) {
                        System.out.println(e.toString());
                    }
                } while (checkTel);

                //        입력한 데이터들을 데이터베이스에 저장하는 메서드 호출
                int result = managerService.insertUser(UserDto.commOf(id, pw, userName, telNum));
                if (result != 0) {
                    System.out.println("새로운 회원이 생성 되었습니다!");
                    System.out.println("=====가입정보=====");
                }
                userInfo();


            case 2:         // 수정 해야됨!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
                UserDto oldDto = null;
                int result1 = 0;
                System.out.println("회원정보 수정 페이지입니다 \n 수정하실 회원의 번호를 입력하세요");
                int user = sc.nextInt();
                System.out.println(user + "번 회원의 새로운 아이디를 입력하세요");
                String setUserId = sc.next();
                System.out.println(user + "번 회원의 새로운 비밀번호를 입력하세요");
                String setUserPw = sc.next();
                System.out.println(user + "번 회원의 새로운 이름를 입력하세요");
                String setUserName = sc.next();
                System.out.println(user + "번 회원의 새로운 연락처를 입력하세요");
                String setUserTel = sc.next();

                result1 = managerService.userUpdate(UserDto.commOf(setUserId,setUserPw,setUserName,setUserTel));
                if (result1 != 0) {
                    System.out.println("회원 수정이 완료 되었습니다");
                } else {
                    System.out.println("회원 수정에 실패 하였습니다.");
                }

                userInfo();

            case 3:
                System.out.println("회원정보 삭제 페이지입니다 \n 삭제하실 회원의 번호를 입력하세요");
                int userNo = sc.nextInt();
                System.out.println(managerService.userDelete(userNo));
                System.out.println(userNo + "번의 회원이 삭제 되었습니다");
                userInfo();
                break;

            case 4:
                System.out.println("회원정보 조회 페이지입니다 \n 조회하실 회원의 번호를 입력하세요");
                int userId = sc.nextInt();
                System.out.println(managerService.userInfo(userId));
                userInfo();
                break;

            case 5:
                return;
        }

    }



//        판매관리 페이지
//        - 판매관리 :
//	ⓐ 관리자는 제품별 판매현황을 확인할 수 있습니다.
//        (제품명, 판매수량, 판매금액)
//	ⓑ 관리자는 회원별 판매현황을 확인할 수 있습니다.
//        (회원아이디, 회원명, 구매금액, 충전잔액)
    private void salesManage() {
        System.out.println("판매 관리 페이지입니다");
        System.out.println("(1) 제품별 판매 현황 (2) 회원별 판매 현황");
        int num = sc.nextInt();
        switch (num) {
            case 1:
                System.out.println("제품별 판매 현황 페이지입니다");

            case 2:
                System.out.println("회원별 판매 현황 페이지입니다");

        }
    }

}
