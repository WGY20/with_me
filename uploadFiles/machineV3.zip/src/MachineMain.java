import view.ManagerView;
import view.UserView;

import java.util.Scanner;

public class MachineMain {
    public static void main(String[] args) {
        UserView userView = new UserView();
        ManagerView managerView = new ManagerView();
        Scanner sc = new Scanner(System.in);
        int loginOrSign;
        boolean stayLogin = false;       // 로그아웃 상태


        // 회원가입 로그인 나누기
        while (true){
            do {
                System.out.println("(1) 로그인 / (2) 회원가입 / (3) 종료");
                System.out.println("번호를 입력하여 주세요.");
                loginOrSign = sc.nextInt();
            } while (loginOrSign<0 || loginOrSign > 4);

                switch (loginOrSign){
                    case 1:         // 로그인
                        boolean loginCheck = userView.loginView();
                        if(loginCheck) {
                            // 다음 화면을 보여주게 하고 빠져나오게 해야 됨
                            userView.choiceView();
                        }
                        break;

                    case 2:         // 회원가입
                        try {
                            userView.signInView();
                        } catch (Exception e) {
                            throw  new RuntimeException(e);
                        }
                        break;
                    case 3:         // 종료
                        return;

                    case 4:
//                        if ()
                        managerView.managerMenu();
                }

        }


    }
}