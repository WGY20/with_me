package excetion;

import java.util.regex.Pattern;

public class InputValidation {

//    휴대폰 양식 체크
    public void phoneCheck(String phone) throws MyException{
        boolean check = Pattern.matches(
                "(010)-(\\d{3,4})-(\\d{4})", phone);
        if (! check){
            throw new MyException("휴대폰 입력 형식은 [010-xxxx-xxxx] 입니다");
        }
    }

    public void nameCheck(String name) throws MyException{
        boolean check = Pattern.matches("^[ㄱ-ㅎ가-힣]*$", name);
        if (! check){
            throw new MyException("이름은 한글로 입력 해주세요");
        }
    }


//    돈이 천원 단위로 떨어지는지 확인
    private static boolean isMultipleOf1000(int money) {
        return money % 1000 == 0;
    }
    public void plusMoneyCheck(int money) throws MyException{
        if (money < 1000) {
            throw new MyException("충전 금액은 1,000원 이상이어야 합니다.");
        }

        if (!isMultipleOf1000(money)) {
            throw new MyException("충전 금액은 1,000원 단위로 입력해주세요.");
        }
    }

//    제품 수량 확인
    public void checkStock(int stock) throws MyException {
        if (stock < 1) {
            throw new MyException("재고 부족으로 판매가 불가능합니다.");
        }

    }

    public static void checkPrice(int money, int price) throws MyException {
        if (money < price) {
            throw new MyException("잔액이 부족하여 구매가 불가능합니다.");
        }
    }




}
