package service;

import db.DBConn;
import dto.UserDto;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class ManagerService {

//    회원정보 입력

//    회원정보 수정

//    회원정보 삭제

//    회원정보 조회
    public UserDto userInfo(int userNo) {
        Connection conn = DBConn.getConnection();
        PreparedStatement psmt = null;
        ResultSet rs = null;
        String sql;
        UserDto dto = null;
        try {
            sql = "select * from user where user_no = ?";
            psmt = conn.prepareStatement(sql);
            psmt.setInt(1, userNo);
            rs = psmt.executeQuery();
            while (rs.next()){
                dto = UserDto.allOf(
                        rs.getInt("user_no"),
                        rs.getString("user_id"),
                        rs.getString("user_pw"),
                        rs.getString("user_name"),
                        rs.getString("user_tel"),
                        rs.getInt("user_money")
                );
            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
        return dto;
    }


//    회원 삭제하기
    public int userDelete(int userNo) {
        int result = 0;
        Connection conn = DBConn.getConnection();
        PreparedStatement psmt = null;
        String sql;

        try {
            sql = "delete from user where user_no = ?";
            psmt = conn.prepareStatement(sql);
            psmt.setInt(1, userNo);
            result = psmt.executeUpdate();
            psmt.close();

        } catch (SQLException e) {
            System.out.println(e.getMessage());
        } return result;

    }

//    새로운 회원 넣기
    public int insertUser(UserDto dto) {
        int result = 0;
        Connection conn = DBConn.getConnection();
        PreparedStatement psmt = null;
        String sql = null;

        try {
            sql = "INSERT INTO user (user_id, user_pw, user_name, user_tel) VALUES (?, ?, ?, ?);";
            psmt = conn.prepareStatement(sql);
            psmt.setString(1, dto.user_id());
            psmt.setString(2, dto.user_pw());
            psmt.setString(3, dto.user_name());
            psmt.setString(4, dto.user_tel());

            result = psmt.executeUpdate();
            psmt.close();

        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
        return result;
    }


//      기존 회원 업데이트 하기
    public int userUpdate(UserDto dto) {
        Connection conn = DBConn.getConnection();
        PreparedStatement psmt = null;
        String sql = null;
        int result = 0;

        try {
            sql = "update user set user_id = ?, user_pw = ?, user_name = ?, user_tel = ? where user_no = ?";
            psmt = conn.prepareStatement(sql);
            psmt.setString(1, dto.user_id());
            psmt.setString(2, dto.user_pw());
            psmt.setString(3, dto.user_name());
            psmt.setString(4, dto.user_tel());
            psmt.setInt(5, dto.user_no());

            result = psmt.executeUpdate();
            psmt.close();

        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
        return result;
    }
}
