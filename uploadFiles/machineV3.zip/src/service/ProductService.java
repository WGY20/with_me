package service;

import com.sun.source.tree.BreakTree;
import db.DBConn;
import dto.ProductDto;
import dto.UserDto;
import excetion.InputValidation;
import excetion.MyException;
import view.UserView;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class ProductService {
    InputValidation validation = new InputValidation();

    //      판매중인 제품 목록 불러오기
        public List<ProductDto> getListAll(){
            List<ProductDto> dtoList = new ArrayList<>();
            Connection conn = DBConn.getConnection();
            PreparedStatement psmt = null;
            ResultSet rs = null;
            String sql;
            try {
                sql = "select * from product order by product_id";
                psmt = conn.prepareStatement(sql);
                rs = psmt.executeQuery();
                while (rs.next()){
                      dtoList.add(ProductDto.allOf(
                              rs.getInt("product_id"),
                              rs.getString("product_name"),
                              rs.getInt("product_price"),
                              rs.getInt("product_stock")
                      ));
                }
                psmt.close();
                rs.close();

            } catch (SQLException e) {
                System.out.println(e.getMessage());
            } return dtoList;
        }


//        구매한 제품을 sales 테이블에 넣기
        public int buyProduct(int uerNum, int pdId) {
            Connection conn = DBConn.getConnection();
            PreparedStatement psmt = null;
            String sql = null;
            int result = 0;

            try {
                sql = "insert into sales (user_no, product_id) values (?, ?)";
                psmt = conn.prepareStatement(sql);
                psmt.setInt(1, uerNum);
                psmt.setInt(2, pdId);
                result = psmt.executeUpdate();
                psmt.close();

            } catch (SQLException e) {
                System.out.println(e.getMessage());
            }
            return result;
        }


//        제품 판매 수량 차감하기
        public int discountStock(int pd){
            Connection conn = DBConn.getConnection();
            PreparedStatement psmt = null;
            String sql = null;
            int result = 0;

            try {
                sql = "update product set product_stock = product_stock -1 where product_id =?";
                psmt = conn.prepareStatement(sql);
                psmt.setInt(1, pd);
                result = psmt.executeUpdate();
                psmt.close();

            } catch (SQLException e) {
                System.out.println(e.getMessage());
            }
            return result;
        }





}
