package service;

import db.DBConn;
import dto.ProductDto;
import dto.UserDto;
import view.UserView;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class UserService {

    public static int userNo;

    // 로그인 확인
    public UserDto selectID(String user_id) {
        Connection conn = DBConn.getConnection();
        PreparedStatement psmt = null;
        ResultSet rs = null;
        UserDto dto = null;
        String sql = null;
        try {
            sql = "select * from user where user_id=?";
            psmt = conn.prepareStatement(sql);
            psmt.setString(1, user_id);
            rs = psmt.executeQuery();
            while (rs.next()) {
                dto = UserDto.allOf(
                        userNo = rs.getInt("user_no"),
                        rs.getString("user_id"),
                        rs.getString("user_pw"),
                        rs.getString("user_name"),
                        rs.getString("user_tel"),
                        rs.getInt("user_money")
                );
            }
            psmt.close();
            rs.close();
            return dto;
        } catch (SQLException e) {
            System.out.println();
        }
        return dto;
    }

    public boolean login(String id, String password) {
        UserDto dto = selectID(id);
        if (dto != null && dto.user_pw().equals(password)) {
            return true;
        }
        return false;
    }

//    회원 계정 만들기
    public int createID (UserDto dto){
        int result = 0;
        Connection conn = DBConn.getConnection();
        PreparedStatement psmt = null;
        String sql = null;

        try {
            sql = "insert into user (user_id, user_pw, user_name, user_tel) values (?, ?, ?, ?)";
            psmt = conn.prepareStatement(sql);
            psmt.setString(1, dto.user_id());
            psmt.setString(2, dto.user_pw());
            psmt.setString(3, dto.user_name());
            psmt.setString(4, dto.user_tel());

            result = psmt.executeUpdate();
            psmt.close();

        } catch (SQLException e) {
            System.out.println(e.getMessage());

        }
        return result;
    }

//    회원 정보 출력 하기
    public UserDto userInfo(int userNo) {
        Connection conn = DBConn.getConnection();
        PreparedStatement psmt = null;
        ResultSet rs = null;
        String sql;
        UserDto dto = null;
        try {
            sql = "select user_id, user_name, user_tel, user_money from user where user_no = ?";
            psmt = conn.prepareStatement(sql);
            psmt.setInt(1, userNo);
            rs = psmt.executeQuery();
            while (rs.next()){
                dto = UserDto.userInfo(
                        rs.getString("user_id"),
                        rs.getString("user_name"),
                        rs.getString("user_tel"),
                        rs.getInt("user_money")
                );
            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
        return dto;
    }

//    현재 금액 출력
    public static int currentMoney() {
        Connection conn = DBConn.getConnection();
        PreparedStatement psmt = null;
        ResultSet rs = null;
        String sql;
        UserDto dto = null;

        try {
            sql = "select user_id, user_money from user where user_no = ?";
            psmt = conn.prepareStatement(sql);
            psmt.setInt(1, userNo);
            rs = psmt.executeQuery();
            while (rs.next()){
                return rs.getInt("user_money");
            }

        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
        return 0;
    }


//      카드 충전
    public int plusMoney(int money, int id){
        Connection conn = DBConn.getConnection();
        PreparedStatement psmt = null;
        String sql = null;
        int result = 0;

        try {
            sql = "update user set user_money = user_money + ? where user_no =?";
            psmt = conn.prepareStatement(sql);
            psmt.setInt(1, money);
            psmt.setInt(2, id);
            result = psmt.executeUpdate();
            psmt.close();

        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
        return result;
    }


//    상품 구매 후 현금 차감
    public void discountMoney(int pdMoney) {
        Connection conn = DBConn.getConnection();
        PreparedStatement psmt = null;
        String sql = null;
        int result = 0;

        try {
            sql = "UPDATE user " +
                    "INNER JOIN product " +
                    "ON user.user_no = user.user_no SET user.user_money = user.user_money - product.product_price " +
                    "WHERE user.user_no = ? AND product.product_id = ?";
            psmt = conn.prepareStatement(sql);
            psmt.setInt(1, userNo);
            psmt.setInt(2, pdMoney);
            result = psmt.executeUpdate();
            psmt.close();

        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }



}