package dto;

public record UserDto(int user_no,
                      String user_id,
                      String user_pw,
                      String user_name,
                      String user_tel,
                      int user_money) {
    public static UserDto allOf(int user_no, String user_id,
                                String user_pw, String user_name, String user_tel, int user_money){
        return new UserDto(user_no, user_id, user_pw, user_name, user_tel, user_money);
    }

//    회원가입 시 정보
    public UserDto(int user_no, String user_id, String user_pw, String user_name, String user_tel) {
        this(user_no, user_id, user_pw, user_name, user_tel, 0);
    }
    public static UserDto commOf( String user_id, String user_pw, String user_name, String user_tel){
        return new UserDto(0, user_id, user_pw, user_name, user_tel, 0);
    }



    //    유저 정보
    public static UserDto userInfo( String user_id, String user_name, String user_tel, int user_money){
        return new UserDto(0, user_id, null, user_name, user_tel, user_money);
    }
    @Override
    public String toString() {
        String str;
        str = String.format("%s \t %s \t %s \t %d \t", user_id, user_name, user_tel,user_money);
        return str;
    }

    public static UserDto moneyInfo( String user_id, int user_money){
        return new UserDto(0, user_id, null, null, null, user_money);
    }

}
