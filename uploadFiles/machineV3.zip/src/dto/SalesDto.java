package dto;

public record SalesDto(
        int sales_id,
        int user_no,
        int product_id) {

    public static SalesDto allOf(
            int sales_id,
            int user_no,
            int product_id) {
        return new SalesDto(sales_id, user_no, product_id);
    }
}
