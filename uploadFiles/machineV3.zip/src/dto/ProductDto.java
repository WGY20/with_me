package dto;

public record ProductDto(
        int product_id,
        String product_name,
        int product_price,
        int product_stock) {
    public static ProductDto allOf(int product_id,
                                String product_name,
                                int product_price,
                                int product_stock){
        return new ProductDto(product_id, product_name, product_price, product_stock);
}


    public ProductDto(String product_name,
                      int product_price,
                      int product_stock) {
        this(0, product_name, product_price, product_stock);
    }

    public static ProductDto commOf(String product_name, int product_price, int product_stock){
        return new ProductDto(0,product_name,product_price,product_stock);
    }

    @Override
    public String toString() {
        String str;
        str = String.format("%d \t %s \t %d \t %d \t", product_id,product_name,product_price,product_stock);
        return str;
    }

}


