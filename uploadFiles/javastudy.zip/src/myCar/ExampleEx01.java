package myCar;
// Q. 가솔린 8.86L 를 충전한 A 자동차는 총 182.736 km 를 운행할 수 있다고 한다.
//이 차의 연비는?  (단 소수 이하를 버리고 정수치만 표기하시오)

public class ExampleEx01 {

    static double calc(double gasoline, double distance){
        return distance / gasoline;
    }

    public static void main(String[] args) {

        double gasoline = 8.86;
        double distance = 182.736;

        System.out.println((int)calc(gasoline, distance));
        System.out.println("연비는" + (int)distance/(int)gasoline);
    }
}
