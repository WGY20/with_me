package ch06;

public class ForEx01 {
    public static void main(String[] args) {
        int num = 0;
        for (int i=2; i <= 9; i++){
            for (int j=1; j<=9; j++) {
                num = i * j;
                if (j==9){
                    System.out.println(i + "*" + j + "=" + num);
                    System.out.println("----------");
                } else {
                    System.out.println(i + "*" + j + "=" + num);
                }

            }
        }
    }
}
