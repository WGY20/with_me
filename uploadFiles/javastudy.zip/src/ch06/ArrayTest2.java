package ch06;

public class ArrayTest2 {
    public static void main(String[] args) {
//        1부터 10까지의 값 합산. 단 5는 빼고 더한다
        int sum = 0;
        for (int i=0; i<=10; i++) {
            sum = sum + i;
        }
        sum = sum - 5;
        System.out.println(sum);

        sum = 0;
        for (int i =0; i<=10; i++) {
            if (i == 5) {
//                continue, break, return
//                continue; --> 해당하는 단계만 빠져나가고 나머지 실행
//                break; --> 중간에  조건이 만족 되면 메서드를 빠져나간다 (뒤로 할 대상이 없을 때 사용)
//                return;  -->
            } else {
                sum = sum + i;
                System.out.println(i);
            }
        }
        System.out.println("메서드 종료");
    }
}
