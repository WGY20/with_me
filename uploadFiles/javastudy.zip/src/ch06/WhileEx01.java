package ch06;

public class WhileEx01 {
    public static void main(String[] args) {
        int n = 1;
//        무한으로 계속 돌아가게 한다
        while (n < 10){
            System.out.println("지금은 True 입니다");
            n = n + 1;
        }

        boolean a = true;
        while (a){
            System.out.println("지금은 트루!");
            a = false;
        }

//        do는 무조건 1번은 실행 해야됨!
        do {
            System.out.println("지금은 트루!!!");
           if(a == true) break;
        } while (a = true);
    }
}
