package ch06;

import java.util.Scanner;

public class SwitchEx01 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("숫자를 입력 하세요: ");
        int day = sc.nextInt();
//        특정 값이 단순하게 변하는 거면 if문보다 switch가 더 간결하다
        switch (day){
            case 0:
                System.out.println("일요일");
                break;
            case 1:
                System.out.println("월요일");
                break;
            case 2:
                System.out.println("화요일");
                break;
            case 3:
                System.out.println("수요일");
                break;
            case 4:
                System.out.println("목요일");
                break;
            case 5:
                System.out.println("금요일");
                break;
            case 6:
                System.out.println("토요일");
                break;
            default:
                System.out.println("감사합니다");
        }
    }
}
