package ch06.diceProblem;

import java.awt.event.WindowAdapter;
import java.util.Random;

public class DiceProblem01 {
    public static void main(String[] args) {
        // 주사위 1개를 3만번 던졌을 때, 각 번호가 나올 확률값을 소수 이하 6자리까지 구하기
        int[] diceNum = new int[6];
        int num = 0;
        Random random = new Random();

        for (int i=0; i<100000; i++){
            num = random.nextInt(6) + 1;
            diceNum[num - 1]++;
        }
        for (int i = 0; i <diceNum.length; i++) {
            System.out.println((i + 1) + ":" + diceNum[i] + "번 (" + String.format("%6f",(double)diceNum[i]/100000) + ")" );
        }

        int total = 0;
        for (int i = 0; i<diceNum.length; i++){
            total = total + diceNum[i];
        }
        System.out.println("던진 횟수: " + total);
    }
}


//1. int[] diceNum = new int[6];
//
//int[]은 정수형 배열을 의미합니다.
//diceNum이라는 이름의 배열을 선언하고 6개의 정수를 저장할 수 있도록 크기를 6으로 설정합니다.
//이 배열은 각 숫자가 나온 횟수를 저장하는 데 사용됩니다.
//2. int num = 0;
//
//num 변수는 주사위가 나온 숫자를 저장할 변수입니다.
//3. Random random = new Random();
//
//Random 클래스는 랜덤 숫자를 생성하는 클래스입니다.
//        new 연산자를 사용하여 Random 클래스의 새로운 인스턴스를 생성하고 random 변수에 저장합니다.
//        4. for (int i=0; i<30000; i++){
//
//        for 루프를 사용하여 3만번 주사위를 굴립니다.
//i 변수는 반복 횟수를 나타냅니다.
//5. num = random.nextInt(6) + 1;
//
//        random.nextInt(6)은 0부터 5까지 랜덤 숫자를 생성합니다.
//        + 1을 통해 1부터 6까지 랜덤 숫자를 생성합니다.
//이 숫자는 주사위가 나온 숫자를 나타냅니다.
//        6. diceNum[num - 1]++;
//
//diceNum 배열의 num - 1번째 요소에 1을 더합니다.
//num - 1은 주사위가 나온 숫자에 해당하는 배열 인덱스입니다.
//이렇게 하면 각 숫자가 나온 횟수를 배열에 저장할 수 있습니다.
//        7. for (int i = 0; i <diceNum.length; i++) {
//
//diceNum 배열의 모든 요소를 반복합니다.
//i 변수는 반복 횟수를 나타냅니다.
//8. System.out.println((i + 1) + ":" + diceNum[i] + "번 (" + String.format("%6f",(double)diceNum[i]/36000) + ")" );
//
//각 숫자가 나온 횟수와 확률을 출력합니다.
//        String.format("%6f",(double)diceNum[i]/36000)은 확률값을 소수 이하 6자리까지 출력하는 형식 지정자입니다.
//        9. int total = 0;
//
//total 변수는 던진 주사위의 총 횟수를 저장할 변수입니다.
//        10. for (int i = 0; i<diceNum.length; i++){
//
//diceNum 배열의 모든 요소를 반복합니다.
//i 변수는 반복 횟수를 나타냅니다.
//11. total = total + diceNum[i];
//
//total 변수에 각 숫자가 나온 횟수를 더합니다.
//12. System.out.println("던진 횟수: " + total);
//
//던진 주사위의 총 횟수를 출력합니다.