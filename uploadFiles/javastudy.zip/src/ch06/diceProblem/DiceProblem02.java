package ch06.diceProblem;

import java.util.Random;

public class DiceProblem02 {
    public static void main(String[] args) {
        // 두 개의 주사위를 3만번 던졌을 때 각 숫자 조합의 나올 확률값을 소수 이하 6자리까지 구하기
        int[][] diceNum = new int[6][6]; // 6x6 배열
        Random random = new Random();

        for (int i = 0; i < 36000; i++) {
            int num1 = random.nextInt(6) + 1; // 첫 번째 주사위 숫자
            int num2 = random.nextInt(6) + 1; // 두 번째 주사위 숫자
            diceNum[num1 - 1][num2 - 1]++; // 해당 숫자 조합의 횟수 증가
        }

        for (int i = 0; i < diceNum.length; i++) {
            for (int j = 0; j < diceNum[i].length; j++) {
                System.out.printf("%2d,%2d: %3d번 (%6f)\n", i + 1, j + 1, diceNum[i][j], (double) diceNum[i][j] / 36000);
            }
        }

        int total = 0;
        for (int i = 0; i < diceNum.length; i++) {
            for (int j = 0; j < diceNum[i].length; j++) {
                total += diceNum[i][j];
            }
        }
        System.out.println("던진 횟수: " + total);
    }
}