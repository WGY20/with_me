package ch06.bubble;

public class bubble01 {
    public static void main(String[] args) {
        int[] bubble = {7, 4, 5, 1, 3}; // 정렬된 숫자를 저장하는 변수

        for (int i=0; i<=bubble.length - 1; i++) { // 마지막 요소는 비교할 이유가 없어서 -1
            boolean flag = true; // 교환이 일어났는지 확인하는 변수, 교환시작 전 교환 여부 초기화
            for (int j=0; j<bubble.length - 1 -i; j++){ // 이미 정렬된 맨 오른쪽 요소들을 다시 비교할 이유 없어서 -i
                if (bubble[j] > bubble[j + 1]) {
                    int temp = bubble[j]; // 바꿔줄 숫자를 넣을 빈자리 num
                    bubble[j] = bubble[j + 1];
                    bubble[j + 1] = temp;
                    flag = false; // 교환이 일어났음을 표시
                }
            }

            if(flag == true) break;

            System.out.print((i + 1) + "회전: ");
            for(int k = 0; k<bubble.length; k++) {
                System.out.printf(bubble[k] + " ");
            }
            System.out.println();

        }
    }
}


// import java.util.Scanner;
//
//public class Selection {
//    public static void main(String[] args) {
//        Scanner sc =new Scanner(System.in);
//        int[] number = new int[5];
//        int a=0;
//
//
//        for (int i = 0; i < number.length ; i++) {
//            System.out.println((i+1)+"번째 수를 입력하세요");
//            number[i] = sc.nextInt();
//        }
//
//        for (int i = number.length-1; i >0 ; i--) {
//            for (int j = 0; j < i; j++) {
//                if (number[j] > number[j + 1]) {
//                    a = number[j];
//                    number[j] = number[j + 1];
//                    number[j + 1] = a;
//                }
//
//            }
//        }
//        for (int i = 0; i < number.length ; i++) {
//            System.out.println(number[i]);}
//    }
//
//}