package ch06.bubble;

public class Selection01 {
    public static void main(String[] args) {
        int[] arr = {69, 10, 30, 2, 16};
        int i = 0;
        do {
//            결과값 출력
            System.out.print("현재 배열: ");
            for (int num : arr) {
                System.out.print(num + " ");
            }
            System.out.println();

            int minIndex = i; // 현재 위치부터 최솟값을 찾을 인덱스
            for (int j = i + 1; j < arr.length; j++) {
                if (arr[minIndex] > arr[j]) { // 현재 최솟값보다 더 작은 값을 찾으면
                    minIndex = j; // 최솟값 인덱스 갱신
                }
            }

            // 현재 위치와 최솟값 위치를 바꿔 정렬
            int temp = arr[i];
            arr[i] = arr[minIndex];
            arr[minIndex] = temp;
            i++;

        } while (i < arr.length - 1);
    }
}
