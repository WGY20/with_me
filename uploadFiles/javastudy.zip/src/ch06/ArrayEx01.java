package ch06;

public class ArrayEx01 {
    public static void main(String[] args) { // -> String 타입의 배열을 인자로 받는다
        int[] nums = {4, 5, 6};
        System.out.println(nums[0]);
        System.out.println(nums[1]);
        System.out.println(nums[2]);
//        System.out.println(nums[3]);

//        for문 -> 반복 처리할 때 사용
//        1부터 10까지 더하는 루프
        int sum = 0; // i를 더하는 것을 누적한 것을 담을 그릇
        for(int i=1; i<10; i++){ // i가 1부터 10보다 작거나 같을 때 까지 돌린다, i는 for문 안에서만 쓰인다
            sum = sum + i; // i는 더하는 용도로도, 지금이 몇번째인지 횟수 체크용으로도 쓴다
//            sum += i; 윗줄과 같은 문법이다
        }
        System.out.println(sum);

        for(int i=0; i<=2; i++){
            System.out.println("nums["+ i + "]" + nums[i]);
            System.out.println("nums lenght : " + nums.length);
            System.out.println(nums.length - 1);
        }

        for (int i=0; i<nums.length; i++){
            System.out.println("nums["+ i + "]" + nums[i]);
        }

//        advanced for 구문
        for (int i: nums){
            System.out.println("advaned for 구문: " + i);
        }
    }
}
