package ch06.civilNumber;

import java.util.Scanner;

public class realRealCiviNumber {
        public static void main(String[] args) {
            Scanner sc = new Scanner(System.in);
            int[] firstNumber = {2, 3, 4, 5, 6, 7, 8, 9, 2, 3, 4, 5};
            int sum = 0;

            System.out.println("주민번호를 입력하세요: ");
            int[] intJumin = new int[13];
            String[] strJumin = new String[13];
            String jumin = sc.next();
            strJumin = jumin.split("");

            for(int i=0; i<intJumin.length; i++) {
                intJumin[i] = Integer.parseInt(strJumin[i]);
            }
            for (int i = 0; i <12 ; i++) {
                sum= sum + (intJumin[i]* firstNumber[i]);
            }
            sum = (11-(sum%11))%10;

            if (sum == intJumin[12])
            {System.out.println("올바른 주민번호입니다.");}
            else {
                System.out.println("잘못된 주민번호입니다.");}

        }
    }

