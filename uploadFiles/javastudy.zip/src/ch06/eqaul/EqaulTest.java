package ch06.eqaul;

public class EqaulTest {
    public static void main(String[] args) {
        Person person =new Person("김형민", 23);
        Person person1 = new Person("김형민", 23);
        int a = 3;
        int b =3;

        System.out.println(person);
        System.out.println(person1);
        System.out.println("+===============");





        if(a == b) {
            System.out.println("1. a와 b는 같다");
        } else {
            System.out.println("1. a와 b는 같지 않다");
        }

        String str1 = "홍길동";
        String str2 = "홍길동";
        if(str1 == str2) {
            System.out.println("2. str1와 str2는 같다");
        } else {
            System.out.println("2. str1와 str2는 같지 않다");
        }

        String str3 = new String("홍길동") ;
        String str4 = new String("홍길동");
        if(str3 == str4) {
            System.out.println("3. str3와 str4는 같다");
        } else {
            System.out.println("3. str3와 str4는 같지 않다");
//            클래스답게 생성을 하면 번지수가 달라서 다르게 나온다
        }

        String str5 = new String("홍길동") ;
        String str6 = new String("홍길동");
        if(str5.equals(str6)) {
            System.out.println("4. str5와 str6는 같다");
        } else {
            System.out.println("4. str5와 str6는 같지 않다");
        }


        if(person1.equals(person)) {
            System.out.println("5. p1와 p2는 같다");
        } else {
            System.out.println("5. p1와 p2는 같지 않다");
        }

        if(person1.name.equals(person.name)) {
            System.out.println("6. p1와 p2는 같다");
        } else {
            System.out.println("6. p1와 p2는 같지 않다");
        }
    }
}
