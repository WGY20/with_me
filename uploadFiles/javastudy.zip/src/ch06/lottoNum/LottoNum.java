package ch06.lottoNum;

import java.util.Random;

public class LottoNum {

    public static void main(String[] args) {
        // 로또 번호 자동 생성기 (Flag 변수 사용)
        // 1부터 45까지의 숫자 중에서 중복 없이 6개의 숫자를 랜덤하게 생성

        Random random = new Random(); // 랜덤 숫자 생성 클래스
        int[] lottoNumber = new int[6]; // 길이 6인 배열
        boolean[] isGenerated = new boolean[46]; // 숫자가 생성되었는지 여부를 저장하는 배열 (46번까지)

        // 6개의 숫자를 생성
        for (int i = 0; i < lottoNumber.length; i++) {
            int randomNumber;
            do {  // do 루프를 사용하여 랜덤 숫자가 이미 선택되어 있는지 확인
                randomNumber = random.nextInt(45) + 1; // 1부터 45까지 랜덤 숫자 생성
            } while (isGenerated[randomNumber]); // 이미 생성된 숫자라면 다시 생성
                // isGenerated[randomNumber]이 true면 랜덤 숫자가 이미 선택되었음을 의미
                // 랜덤 숫자가 이미 선택되었으면 do 블록의 처음으로 돌아가 다시 랜덤 숫자 생성

            lottoNumber[i] = randomNumber;
            isGenerated[randomNumber] = true; // 생성된 숫자 표시
        }

        // 결과 출력
        for (int number : lottoNumber) { // lottoNumber 배열의 모든 요소 반복, number 배열 요소 저장
            System.out.print("[ " + number + " ]");
        }
    }
}


//코드 줄별 설명:
//
//        1. Random random = new Random();
//
//Random 클래스는 랜덤 숫자를 생성하는 클래스입니다.
//        new 연산자를 사용하여 Random 클래스의 새로운 인스턴스를 생성하고 random 변수에 저장합니다.
//        2. int[] lottoNumber = new int[6];
//
//int[]는 정수형 배열을 의미합니다.
//lottoNumber라는 이름의 배열을 선언하고 6개의 정수를 저장할 수 있도록 크기를 6으로 설정합니다.
//        3. boolean[] isGenerated = new boolean[46];
//
//boolean[]는 논리형 배열을 의미합니다.
//isGenerated라는 이름의 배열을 선언하고 46개의 논리값을 저장할 수 있도록 크기를 46으로 설정합니다.
//        4. for (int i = 0; i < lottoNumber.length; i++) {
//
//        for 루프를 사용하여 lottoNumber 배열의 모든 요소를 반복합니다.
//i 변수는 반복 횟수를 나타내며 0부터 5까지 증가합니다.
//        5. int randomNumber;
//
//randomNumber 변수는 랜덤하게 생성된 숫자를 저장할 변수입니다.
//6. do {
//
//        do-while 루프를 사용하여 랜덤 숫자가 이미 선택되었는지 확인합니다.
//7. randomNumber = random.nextInt(45) + 1;
//
//        random.nextInt(45)는 0부터 44까지의 랜덤 숫자를 생성합니다.
//        + 1을 통해 1부터 45까지의 랜덤 숫자를 생성합니다.
//        8. } while (isGenerated[randomNumber]);
//
//isGenerated[randomNumber]이 true이면 랜덤 숫자가 이미 선택되었음을 의미합니다.
//랜덤 숫자가 이미 선택되었으면 do 블록의 처음으로 돌아가 다시 랜덤 숫자를 생성합니다.
//9. lottoNumber[i] = randomNumber;
//
//lottoNumber 배열의 i번째 요소에 randomNumber 값을 저장합니다.
//10. isGenerated[randomNumber] = true;
//
//isGenerated 배열의 randomNumber번째 요소를 true로 설정하여 랜덤 숫자가 선택되었음을 표시합니다.
//        11. }
//
//        for 루프 종료
//12. for (int number : lottoNumber) {
//
//lottoNumber 배열의 모든 요소를 반복합니다.
//number 변수는 각 반복에서 배열의 요소를 저장합니다.
//13. System.out.print("[ " + number + " ]");
//
//number 값을 출력합니다.
//14. }
//
//        for 루프 종료