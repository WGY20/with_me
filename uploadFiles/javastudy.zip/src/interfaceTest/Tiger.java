package interfaceTest;

public class Tiger extends WildAnimalImpl {

    @Override
    public void attack() {
        System.out.println("이빨로 공격");
    }
}
