package interfaceTest;

public interface MoveAndHideInterface {
    void up();
    void down();
    void left();
    void right();
    String hide(); // 되돌려 줄 타입도 정의를 해줘야 함
}
