package interfaceTest;

public interface MoveInterface {
    void small();
    void up();
    void down();
    void left();
    void right();
}
