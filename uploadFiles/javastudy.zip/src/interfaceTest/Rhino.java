package interfaceTest;

public class Rhino extends WildAnimalImpl{
    @Override
    public void attack() {
        System.out.println("뿔로 공격");
    }
}
