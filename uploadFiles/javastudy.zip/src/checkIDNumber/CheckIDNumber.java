package checkIDNumber;

import java.util.Scanner;

public class CheckIDNumber {
    public static void main(String[] args) {
        String num;
        String strNum[] = new String[13]; // 수가 크기 때문에 문자로 받고, str로 배열을 만듦 13자리의 문자가 들어갈 공간
        int[] idNum = new int[13]; // 배열 길이 13 개, 0부터 12까지
        int[] mulNum = {2, 3, 4, 5, 6, 7, 8, 9, 2, 3, 4, 5}; // 곱해줄 값
        int result = 0; // 주민번호에 곱한 값을 더한 값 (중간 계산 값 저장고)
        int idModNum = 0; // 더한 값을 11로 나눈 나머지 값
        int idResultNum = 0; // 11에서 나머지 값을 뺀 값

        System.out.println("주민번호를 입력하세요: ");
        Scanner sc = new Scanner(System.in);
        num = sc.next(); // 입력을 주민번호를 받고 num에 넣는다
        strNum = num.split(""); // 나눌 단위를 정하고 쪼갠 값을 strNum에 넣는다

        for(int i=0; i<idNum.length; i++){
            if (i < 7){
            idNum[i] = Integer.parseInt(strNum[i]);
            result = result + (idNum[i] +(i - 2));// 문자로 입력된 strNum을 int로 바꾼 후 idNum에 넣는다
            }
        }


        for(int i : idNum){
            System.out.println(i);
        }
//
    }
}
