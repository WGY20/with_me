package ch04.b;

import ch04.a.Cal;

public class App {

    public static void main(String[] args) {
        Cal cal = new Cal();
    }
}
