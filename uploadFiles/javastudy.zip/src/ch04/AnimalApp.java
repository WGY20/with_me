package ch04;

import ch04.a.Cal;

public class AnimalApp {
    public static void main(String[] args) {
        Cal cal = new Cal(); // Cal이 갖고있는 메서드 가져오기 가능

    }
}
