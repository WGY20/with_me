package ch04.a;

public class Cal {
    void plus() {
        System.out.println("Plus");
    }
    private void minus() {
        System.out.println("Minus"); // private으로 선언한 변수는 외부에 노출이 안된다
    }
    public void multi() {
        System.out.println("Multi");
    }
    protected void divide(){
        System.out.println("Divide");
    }
//    private은 자기 클래스에서만
//    protected 는 같은 패키지 내부에서만
//    public은 모두가 다 사용 가능


}
