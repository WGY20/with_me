package ch04.calcArea;

public class CalcMain {
//    결과를 뽑아내는 클래스
    public static void main(String[] args) {
        Figure figure = new Figure(3, 4);
        Rectangle rectangle = new Rectangle(figure);
        rectangle.printResult();
        Triangle triangle = new Triangle(figure);
        triangle.printResult();
    }
}
