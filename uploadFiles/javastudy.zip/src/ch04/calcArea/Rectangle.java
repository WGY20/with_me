package ch04.calcArea;

public class Rectangle{
//    자식 클래스 - 사각형
    String name = "사각형";

    Figure figure;
    public Rectangle(Figure figure) {
        this.figure = figure;
    }

    public double calcArea() {
        return figure.getWidth()* figure.getHeight();
    }

    public void printResult() {
        System.out.println("너비: " + figure.getWidth() + ", 높이: "+ figure.getHeight() + "인 " + name + " 넓이는 " + calcArea() + "입니다");
    }

}
