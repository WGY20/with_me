package ch04.calcArea;

public class Triangle {
//    자식 클래스 - 삼각형
    String name = "삼각형";

    Figure figure;

    public Triangle(Figure figure) {
        this.figure = figure;
    }

    public int calcArea() {
        return (figure.getWidth()* figure.getHeight() /2);
    }

    public void printResult() {
        System.out.println("너비: " + figure.getWidth() + ", 높이: "+ figure.getHeight() + "인 " + name + " 넓이는 " + calcArea() + "입니다");
    }

}
