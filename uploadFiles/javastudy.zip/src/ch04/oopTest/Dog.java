package ch04.oopTest;

public class Dog {
    private String name;
    private String color;
    static String type;
    public Dog(String name, String color){
        this.name = name;
        this.color = color;
    }

////    getter - 가지고 오는거
//    public void setColor(String color){
//        this.color = color;
//    }
//
////    setter - 바꾸는거
//    public String getColor(){
//        return color;
//    }

    public void setName(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }
}
