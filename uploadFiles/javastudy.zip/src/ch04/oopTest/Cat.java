package ch04.oopTest;

public class Cat {
    String name;
    String color;

// 기본 생성자가 생략되어 있던 것! (Default constructor)
    public Cat(){}

//    overloading
    public Cat(String cName, String cColor){
        System.out.println("고양이가 탄생 했습니다.");
        name = cName;
        color = cColor;
    }
}
