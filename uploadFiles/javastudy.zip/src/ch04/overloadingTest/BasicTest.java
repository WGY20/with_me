package ch04.overloadingTest;

public class BasicTest {
    void run() {
        System.out.println("일반 달리기");
    }
    void run(int speed){
        System.out.println("달리기 : 정수");
    }
    void run(double speed){
        System.out.println("달리기: 실수");
    }
    void run(int speed, double power) {
        System.out.println("달리기: 정수/실수");
    }
}
