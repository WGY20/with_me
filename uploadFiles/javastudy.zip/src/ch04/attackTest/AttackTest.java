package ch04.attackTest;

public class AttackTest {
    public static void main(String[] args) {
        전사 u1 = new 전사();
        궁수 u2 = new 궁수();
        광전사 u3 = new 광전사();

        u1.기본공격();
        u1.기본공격(u2);
    }
}
