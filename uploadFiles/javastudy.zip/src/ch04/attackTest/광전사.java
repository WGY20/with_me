package ch04.attackTest;

public class 광전사 {
    String name = "광전사";
    void 기본공격(){
        System.out.println("도끼로 공격하기");
    }
    void 기본공격(전사 e1){
        System.out.println("도끼로 " + e1.name + " 공격하기");
    }
}
