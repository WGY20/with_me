package ch04.attackTest;

public class 전사 {
    String name = "전사";
    void 기본공격(){
        System.out.println("검으로 공격하기");
    }
    void 기본공격(궁수 e1){
        System.out.println("검으로 " + e1.name + " 공격하기");
    }
}
