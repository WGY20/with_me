package ch04.starcraft;

public class Zealot extends ProtosUnit {
    String name = "질럿";

    @Override
    void 기본공격(ProtosUnit e1) {
        //super - 상속받은 개체
        System.out.println("질럿 메서드");
        System.out.println(this.name + "이 " + e1.이름확인() + "을 공격합니다!!");
    }

    @Override
    String 이름확인() {
        return this.name;
    }
}
