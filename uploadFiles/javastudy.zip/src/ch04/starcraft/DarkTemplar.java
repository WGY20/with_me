package ch04.starcraft;

public class DarkTemplar extends ProtosUnit{
    String name = "다크탬플러";

    @Override
    void 기본공격(ProtosUnit e1) {
        System.out.println("다크탬플러 매서드");
        System.out.println(this.name + "이 " + e1.name + "을 공격합니다");
    }

    @Override
    String 이름확인() {
        return this.name;
    }
}
