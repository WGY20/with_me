package ch04.starcraft;

public class Reaver extends ProtosUnit{
    String name = "리버";

    @Override
    void 기본공격(ProtosUnit e1) {
        super.기본공격(e1);
    }

    void attack(ProtosUnit unit){
        System.out.println("리버 매서드");
        System.out.println(this.name + "이 " + unit.name + "을 공격합니다");
    }
}
