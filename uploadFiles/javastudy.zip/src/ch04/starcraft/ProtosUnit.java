package ch04.starcraft;

public class ProtosUnit {
//    부모 클래스
    String name = "프로토스유닛";
    void 기본공격(ProtosUnit e1){
        System.out.println("프로토스유닛 메서드");
    }
    String 이름확인() {
        return this.name;
    }

}
