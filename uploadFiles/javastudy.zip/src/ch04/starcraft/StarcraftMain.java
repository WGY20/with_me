package ch04.starcraft;

import ch04.calcArea.Rectangle;

public class StarcraftMain {
//    출력 클래스
    public static void main(String[] args) {
        ProtosUnit u1 = new Zealot();
        ProtosUnit u2 = new Dragoon();
        DarkTemplar u3 = new DarkTemplar();
        Reaver u4 = new Reaver();

        u1.기본공격(u2);
        u2.기본공격(u1);
        u1.기본공격(u3);
        u4.기본공격(u1);
    }
}
