package ch04.starcraft;

public class Dragoon extends ProtosUnit{
    String name = "드라군";

    @Override
    void 기본공격(ProtosUnit e1) {
        System.out.println("드라군 메서드");
        System.out.println(this.name + "이 " + e1.name + "을 공격합니다");
    }

    @Override
    String 이름확인() {
        return this.name;
    }
}
