package legacy;

import java.util.Scanner;

public class Legacy {
    Scanner sc = new Scanner(System.in);

}
