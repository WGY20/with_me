package machine;

import java.util.Scanner;

public class machine1 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int num = 0;
        int[] juice = {1, 2, 3, 4}; // 1: 콜라 2: 사이다 3: 커피 4: 종료

        while (true){
            System.out.println("음료 자판기입니다. 번호를 선택하세요.");
            System.out.println("1: 콜라, 2: 사이다, 3: 커피, 4: 종료");
            num = sc.nextInt();
            if (num == juice[0]){
                System.out.println("콜라를 선택하셨습니다.");
                System.out.println("===================");
            } else if (num == juice[1]) {
                System.out.println("사이다를 선택하셨습니다.");
                System.out.println("===================");
            } else if (num == juice[2]) {
                System.out.println("커피를 선택하셨습니다.");
                System.out.println("===================");
            } else if (num != juice[3]){
                System.out.println("번호를 다시 확인하여 주세요");
                System.out.println("===================");
            }

            if(num == juice[3]) break;
        }
    }
}
