package genericTest;

class Tiger{
    String name = "호랑이";
}

class Lion {
    String name = "사자";
}

class BigBasket<T> {
//    Object data;
    T data;
}

public class GenericEx02 {
    public static void main(String[] args) {
//        BigBasket basket = new BigBasket();
        BigBasket<Tiger> basket = new BigBasket<>();
        basket.data = new Tiger();
        System.out.println(basket.data.name);

        BigBasket<Lion> basket1 = new BigBasket<>();
        basket1.data = new Lion();
        System.out.println(basket1.data.name);
//        System.out.println(((Tiger)basket.data).name);
    }
}
