package abstractPackage;

public class Cat extends Animal{
    @Override
    void speak() {
        System.out.println("냥냥");
    }
}
