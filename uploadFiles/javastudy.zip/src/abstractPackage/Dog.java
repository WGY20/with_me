package abstractPackage;

public class Dog extends Animal{
    @Override
    void speak() {
        System.out.println("왈왈왘크르르렁릉렁");
    }
}
