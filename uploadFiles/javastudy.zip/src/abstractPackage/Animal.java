package abstractPackage;

public abstract class Animal {
    // abstract ==> 의무적으로 구현하게 하고 싶을 때 사용
    void hello(){
        System.out.println("나는 동물입니다");
    }
    abstract void speak(); // 미완성 클래스
}
