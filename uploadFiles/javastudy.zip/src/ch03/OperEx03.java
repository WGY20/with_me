package ch03;

public class OperEx03 {
    public static void main(String[] args) {
        int value = 3;
        System.out.println(1 == 1);
        if(1 ==1) {
            System.out.println(true);
        } else {
            System.out.println(false);
        }

        System.out.println( 5 != 1);
        System.out.println(! true);
        System.out.println(3 > 0);
        System.out.println(value = 3);

//        논리연산자 AND
        int n1 = 1;
        int n2 = 2;
        if(n1 == 1 && n2 == 2) {
            System.out.println(true);
        } else {
            System.out.println(false);
        }
//        논리연산자 OR
        if(n1 == 1 || n2 == 2) {
            System.out.println(true);
        } else {
            System.out.println(false);
        }
    }
}
