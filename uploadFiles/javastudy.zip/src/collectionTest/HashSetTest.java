package collectionTest;

import java.util.*;

public class HashSetTest {

    public static void main(String[] args) {
        Set<String> fruits = new HashSet<>(Arrays.asList("사과", "오렌지"));
        fruits.add("사과");
        for (String fruit : fruits){
            System.out.println(fruit);
        }

        Map<String, Integer> store = new HashMap<>();
        store.put("water" ,1);
        store.put("fire", 2);
        for (String key : store.keySet()){
            System.out.println(key + " : " + store.get(key));
        }
    }
}
