package collectionTest;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;

public class ArrayListTest {
    public static void main(String[] args) {
        ArrayList<String> colors = new ArrayList<>(Arrays.asList("black", "white"));
        colors.add("pink");
        // advanced for
        for (String color : colors){
            System.out.println(color);
        }

        // Iterator 활용
        Iterator<String> iterator = colors.iterator(); // 회전초밥처럼 하나씩 꺼내서 넣는다!!
        while (iterator.hasNext()){
            String c = iterator.next();
            System.out.println(c);
        }
    }

}
