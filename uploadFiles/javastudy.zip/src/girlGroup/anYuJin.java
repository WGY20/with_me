package girlGroup;

public class anYuJin {
        final String name = "안유진";
        int height = 170;
        int year = 2003;
        void sing() {
                System.out.println(name + "이 노래를 부릅니다");
        }

}
