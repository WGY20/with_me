package girlGroup;

public class JangWonYong {
//    이것을 멤버 변수라고 부른다
    String name = "장원영";
    int height = 172;
    int year = 2004;
//    기능은 메서드(Method) 라고 한다
    void dance(){
        System.out.println(name + "이 춤을 춥니다.");
    } // void는 dance가 실행 됐을 때 난 받을 게 없어 라는 뜻
}
