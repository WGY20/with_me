package girlGroup;

public class Ive {

    static void danceAndSing(String name){ // string 타입으로 name을 받는다
        System.out.println(name + "가 춤과 노래를 합니다");
    }
    static String sayHello(String name) {
        String answer = name + "이 인사를 합니다";
        return answer;
    }

    public static void main(String[] args) {
        anYuJin anYuJin = new anYuJin();
        JangWonYong jangWonYong = new JangWonYong();

        int speed;
        speed = 0;
        if(3>4) {
            System.out.println("참입니다");
        } else {
            System.out.println("거짓입니다");
        }

        System.out.println("----------------------------");
        System.out.println(anYuJin.name);
        System.out.println(anYuJin.height);
        anYuJin.sing();
//        anYuJin.name = "An Yu Jin"; final 변수로 선언된 것은 초기값을 바꿀 수 x

        System.out.println("----------------------------");
        System.out.println(jangWonYong.name);
        System.out.println(jangWonYong.height);
        jangWonYong.dance();
        Ive.danceAndSing(anYuJin.name);
        System.out.println(sayHello(jangWonYong.name));
    }
}
