package ch05.compositionAndEx;

public class ChickenHamburger {
    Hamburger hamburger;
    String name = "치킨햄버거";
    public ChickenHamburger(Hamburger hamburger){
        this.hamburger = hamburger;
    }
}
