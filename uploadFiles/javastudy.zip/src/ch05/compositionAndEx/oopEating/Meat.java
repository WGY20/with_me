package ch05.compositionAndEx.oopEating;

public class Meat {
    public void eat(){};
}
