package ch05.compositionAndEx.oopEating;

public class Fruit {
    private String name;
    private String taste;
    public void eat(){};
}
