package ch05.compositionAndEx.oopEating;

public class Mango extends Fruit {
    private String name = "망고";
    private String taste = "달콤한 맛";

    public void eat() {
        System.out.println(taste + " " + name);
    }
}