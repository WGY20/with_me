package ch05.compositionAndEx;

public class Engine {
//    완성품
    private int power = 2000;
    public int getPower(){
        return this.power;
    }
}
