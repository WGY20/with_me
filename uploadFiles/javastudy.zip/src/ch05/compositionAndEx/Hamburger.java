package ch05.compositionAndEx;

public class Hamburger {
    String name = "기본 햄버거";
    String firstContent = "번";
    String secondContent = "양상추";

}
