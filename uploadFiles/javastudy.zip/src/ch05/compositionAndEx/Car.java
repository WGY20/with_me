package ch05.compositionAndEx;

import ch04.oopTest.Cat;

public class Car {
    Engine engine; // 엔진 장착 준비 // 5
    private String brand;
    private String name;
    public Car(Engine engine){ // 3
        this.engine = engine; // 4
    }
}
