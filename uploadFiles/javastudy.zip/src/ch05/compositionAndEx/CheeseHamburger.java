package ch05.compositionAndEx;

public class CheeseHamburger extends Hamburger {
    String name = "치즈 햄버거";

}
