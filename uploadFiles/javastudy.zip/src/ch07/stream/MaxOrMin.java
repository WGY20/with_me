package ch07.stream;

@FunctionalInterface        // 메서드는 하나밖에 못오는 펑션이라는걸 jvm한테 알림
public interface MaxOrMin {
    int maxOrMinValue(int a, int b);
}
