package ch07.stream;

public class LambdaExpressionTest {
    public static void main(String[] args) {
        Calc add = (x, y)->{
            return x+y;
        };

        Calc minus = (a, b)-> a-b;

        Calc multy = (x, y) ->{
            return x*y;
        };

        System.out.println(add.calc(3,6));
        System.out.println(minus.calc(5,2));
        System.out.println(multy.calc(3,1));
    }

}
