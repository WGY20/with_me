package ch07.stream;

public interface Calc {
    int calc(int x, int y);
}
