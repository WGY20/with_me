package ch07.thread;

class SubThread implements Runnable {       // thread를 돌리려면 Runnable을 꼭 implements 해야 된다

    @Override
    public void run() {
        for (int i=1; i <=5; i++){
            try {
                System.out.println("서브스레드 : " + i);
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }
}

public class ThreadEx01 {
    public static void main(String[] args) {
        for (int i = 1; i<=5; i++) {
            SubThread subThread = new SubThread();
            Thread thread = new Thread(subThread);
            thread.start();         // subthread 돌려준다
            try {
                System.out.println("메인스레드 : " + i);
                Thread.sleep(2000);     // 1000ms -> 1초

            } catch (InterruptedException e) {
                e.printStackTrace();
            }

        }
    }

}
