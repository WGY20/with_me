package interfaceQuiz;

public interface RemoconAble {
    void greenButton();
    void redButton();

}
