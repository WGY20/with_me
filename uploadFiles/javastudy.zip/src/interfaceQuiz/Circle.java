package interfaceQuiz;

public class Circle implements AreaInterface{
//    원
    public double radius;

    public Circle(double radius){
        this.radius = radius;
    }

    @Override
    public void getArea() {
        System.out.println("원의 넓이는 " + this.radius*this.radius* Math.PI + " 입니다");
    }



}
