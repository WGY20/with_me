package interfaceQuiz;

public class SamsungTv implements RemoconAble{
    final private String name = "삼성티비";

    public String getName(){
        return this.name;
    }
    @Override
    public void greenButton() {
        System.out.println(this.name + " 전원이 커졌다");
    }

    @Override
    public void redButton() {
        System.out.println("전원이 꺼졌");
    }
}
