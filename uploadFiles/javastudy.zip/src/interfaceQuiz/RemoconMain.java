package interfaceQuiz;

public class RemoconMain {
    public static void main(String[] args) {
        SamsungTv samsungTv = new SamsungTv();
        samsungTv.greenButton();
        samsungTv.redButton();

        RemoconAble samsung = new SamsungTv();
        samsung.greenButton();
    }
}
