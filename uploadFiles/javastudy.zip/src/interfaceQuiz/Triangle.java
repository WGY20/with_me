package interfaceQuiz;

public class Triangle implements AreaInterface{

//    삼각형
    public int width;
    public int height;

    public Triangle(int width, int height){
        this.width = width;
        this.height = height;
    }


    @Override
    public void getArea() {
        System.out.println("삼각형의 넓이는 " + (this.height * this.width)/2 +" 입니다");
    }
}
