package interfaceQuiz;

public interface AreaInterface {
    void getArea(); // 넓이 구하기
}
