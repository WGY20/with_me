package interfaceQuiz;

public class FigureMain {
    public static void main(String[] args) {

    // 삼각형 넓이 출력
        Triangle triangle = new Triangle(10,20);
        triangle.getArea();

//    사각형 넓이 출력
        Rectangle rectangle = new Rectangle(20,87);
        rectangle.getArea();

//    원의 넓이 출력
        Circle circle = new Circle(25);
        circle.getArea();
    }


}
