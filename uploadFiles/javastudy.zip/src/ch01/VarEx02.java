package ch01;
// VarEx02 아래에 있는 클래스이다 (총 12byte, Note라는 변수의 덩어리라고 본다 -> 클래스 자료형 이라 칭함)
class Note{ // static을 사용하면 메모리 사용량이 올라감, New라는 키워드로 호출이 되면 힙에서 만들어짐
    int num = 1;
    int price = 1000;
    int quantity = 1;
}

public class VarEx02 {
    public static void main(String[] args) {
        Note note = new Note(); //note는 위에 있는 12bye 3개 type인 변수로 선언됨 (위치한 주소값을 알려줌)
        Note note1 = new Note();
        Integer intNum = 100;

//        첫번째 노트 가격
        System.out.println("첫번째 노트 가격 : " + note.price);

//        두번째 노트 가격
        note1.price = 2000;
        System.out.println("두번째 노트 가격 : " +note1.price);

        붕어빵 bang = new 붕어빵();
        System.out.println(bang.color);
        System.out.println(bang.price);
        System.out.println(bang.taste);
    }
}
