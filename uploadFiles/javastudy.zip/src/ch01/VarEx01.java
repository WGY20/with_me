package ch01;


public class VarEx01 {
    static int n2 = 30;
    public static void main(String[] args) {
//      변수의 선언
        boolean booleanTrue = true;
        boolean booleanFalse = false; // 변수의 초기값을 바로 준 것
        int intNumber = 0;
        intNumber = intNumber  + 1;
        double doubleNumber = 100.1;
        char charString = '가';

        double resultNum = intNumber + doubleNumber;
//        int resultNum2 = intNumber + doubleNumber;
//        정수와 실수를 더하고 정수로 나타내려 해서 오류, 정수 + 실수는 실수이므로 double로 출력

        int resultNumInt = (int)(intNumber + doubleNumber);
        int resultNumInt2 = intNumber + (int)doubleNumber;
//        타입을 억지로 바꿔주는 법!

        System.out.println("booleanTrue = " + booleanTrue);
        System.out.println("booleanFalse = " + booleanFalse);
        System.out.println("int intNumber = " + intNumber);
        System.out.println("double d1 = " + doubleNumber);
        System.out.println(resultNum);

        System.out.println(n2);

        charString = '나';

        System.out.println("char c1 = " + charString);

    }
}
