package ch01;

public class 붕어빵 {
    int price = 1000;
    String taste = "달콤함";
    String color = "노란색";
}
