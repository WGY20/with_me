package com.example.oxquiz.dto;

import lombok.Getter;

@Getter
public enum QuizAnswerEnum {
    O(1, true), X(0, false);

    private final boolean description;
    QuizAnswerEnum(String number, boolean b, boolean description) {
        this.description = description;
    }
}
