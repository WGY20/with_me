package com.example.oxquiz.entity;

import jakarta.persistence.*;
import lombok.Data;

@Entity
@Data
public class Quiz {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column
    private Long id;

    @Column(nullable = false)
    private String quizContent;

    @Column(columnDefinition = "boolean default false")
    private boolean quizAnswer;

    @Column(length = 20)
    private String quizAuthor;

}
