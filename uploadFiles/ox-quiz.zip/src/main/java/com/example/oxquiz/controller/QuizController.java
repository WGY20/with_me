package com.example.oxquiz.controller;

import com.example.oxquiz.dto.QuizDto;
import com.example.oxquiz.entity.Quiz;
import com.example.oxquiz.repository.QuizRepository;
import com.example.oxquiz.service.QuizService;
import jakarta.validation.Valid;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import java.util.List;

@Controller
@RequestMapping("/quiz")
public class QuizController {

    private final QuizService quizService;

    public QuizController(QuizService quizService) {
        this.quizService = quizService;
    }


    //    퀴즈 목록 (첫 화면)
    @GetMapping("")
    public String quizList(Model model) {
        List<QuizDto> dtoList = quizService.showAllQuizs();
        model.addAttribute("quizDto", dtoList);
        return "/quizList";
    }


    //    퀴즈 등록 폼으로
    @GetMapping("/insertQuiz")
    public String insertQuizForm(Model model) {
        model.addAttribute("quizDto", new QuizDto());
        return "/insertQuiz";
    }


//    퀴즈 등록
    @PostMapping("/insertQuiz")
    public String insertQuiz(@Valid @ModelAttribute("quizDto") QuizDto quizDto,
                             BindingResult bindingResult) {
        if (bindingResult.hasErrors()) {
            return "insertQuiz";
        }
        quizService.insertQuiz(quizDto);
        return "redirect:/quiz/quizList";
    }


//    퀴즈 수정 폼


//    퀴즈 수정


//    퀴즈 삭제


//    퀴즈 풀이화면 표시


//    퀴즈 답 체크

}