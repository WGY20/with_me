package com.example.oxquiz.dto;


import com.example.oxquiz.entity.Quiz;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@ToString
@AllArgsConstructor
@NoArgsConstructor
public class QuizDto {
    private Long id;

    @NotBlank(message = "퀴즈 내용을 입력 해주세요!")
    private String quizContent;

    @Size(max = 20, message = "닉네임은 최대 20자입니다")
    private boolean quizAnswer;

    @NotBlank(message = "정답을 입력 해주세요!")
    private String quizAuthor;



//    Entity인 Quiz를 Dto로 변환
    public static QuizDto fromQuizEntity(Quiz quizDto) {
        return new QuizDto(
                quizDto.getId(),
                quizDto.getQuizContent(),
                quizDto.isQuizAnswer(),
                quizDto.getQuizAuthor()
        );
    }

    //    dto를 Entity로 변환
    public Quiz fromQuizDto(QuizDto quizDto) {
        Quiz quiz = new Quiz();
        quiz.setId(quizDto.getId());
        quiz.setQuizContent(quizDto.getQuizContent());
        quiz.setQuizAnswer(isQuizAnswer());
        quiz.setQuizAuthor(quizDto.getQuizAuthor());
        return quiz;
    }


}
