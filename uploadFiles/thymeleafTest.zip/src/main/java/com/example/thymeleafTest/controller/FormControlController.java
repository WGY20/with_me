package com.example.thymeleafTest.controller;


import com.example.thymeleafTest.vo.EmailOptionsDto;
import com.example.thymeleafTest.vo.GenderDto;
import com.example.thymeleafTest.vo.SignUp;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import java.util.Map;

@Slf4j
@Controller
public class FormControlController {

    @ModelAttribute("gender")
    private GenderDto[] genders() {
        return GenderDto.values();
    }

    @ModelAttribute("emailOption")
    private EmailOptionsDto[] emailOption() {
        return EmailOptionsDto.values();
    }

    @GetMapping("/signUp")
    public String signUp(Model model) {
        model.addAttribute("dto", new SignUp());
        return "signUpView";
    }

    @PostMapping("/signUp")
    public String signUp(@ModelAttribute("dto") SignUp signUp) {
        log.info("User Id = " + signUp.getId());
        log.info("User Password = " + signUp.getPassword());
        log.info("User Name = " + signUp.getName());
        log.info("User Birth = " + signUp.getBirth());
        log.info("User Gender = " + signUp.getGender());
        log.info("User Email = " + signUp.getEmail() + "@" + signUp.getEmailOption());
        log.info("User PhoneNum = " + signUp.getPhoneNum());
        log.info("User Terms item1 = " + signUp.isTerm1());
        log.info("User Terms item2 = " + signUp.isTerm2());
        log.info("User Terms item3 = " + signUp.isTerm3());
        return "/formControlResultView";
    }

//    @ModelAttribute("emailList")
//    private Map<String, String> emailList() {
//        Map<String>
//    }
}
