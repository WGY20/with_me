package com.example.thymeleafTest.vo;


import lombok.Data;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.util.List;

@Getter
@Setter
@ToString

@Data
public class SignUp {
    private String  Id;
    private String password;
    private String name;
    private String birth;
    private String gender;
    private boolean term1;
    private boolean term2;
    private boolean term3;
    private String email;
    private String emailOption;
    private String fullEmail;
    private String phoneNum;
}
