package com.example.thymeleafTest.vo;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.util.List;

@Getter
@Setter
@ToString

@Data
public class FormDto {
    private String name;
    private boolean trueOrFalse;
    private List<String> hobbies;      // multi checkbox 용
    private String language;    // radio button 용
    private String country;     // select
}
