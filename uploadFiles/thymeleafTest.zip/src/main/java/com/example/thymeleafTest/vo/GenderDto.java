package com.example.thymeleafTest.vo;

import lombok.Getter;

@Getter
public enum GenderDto {
    MEN("남성"), WOMEN("여성"), NONE("선택안함");
    private final String gender;

    GenderDto(String gender) {
        this.gender = gender;
    }
}
