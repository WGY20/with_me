package com.example.thymeleafTest.vo;

import lombok.Getter;

@Getter
public enum EmailOptionsDto {
    naver("naver.com"), gmail("gmail.com"), kakao("kakao.com");
    private final String emailOption;

    EmailOptionsDto(String emailOption) {

        this.emailOption = emailOption;
    }
}
