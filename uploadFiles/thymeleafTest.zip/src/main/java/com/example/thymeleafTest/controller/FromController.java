package com.example.thymeleafTest.controller;

import com.example.thymeleafTest.vo.Country;
import com.example.thymeleafTest.vo.FormDto;
import com.example.thymeleafTest.vo.Language;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Controller     // 나는 컨트롤러다!!!!!!!
@Slf4j          // log.info 를 사용해서 출력
public class FromController {

    @ModelAttribute("language")     // Model이 들어간 모든 곳에 자동으로 넣어서 보낸다
    private Language[] languages(){
        return Language.values();
    }

    @ModelAttribute("country")
    private Country[] countries(){
        return Country.values();
    }


    @GetMapping("/form")        // 화면을 보여주기만 할 곳
    public String showForm(Model model) {

        model.addAttribute("dto", new FormDto());       // dto 속성이 있는 빈 상자 보내기
        return "formTest/form";
    }

    @PostMapping("/form")       // 전송버튼을 누를때 post 받을 곳
    public String postForm(@ModelAttribute("dto") FormDto dto) {       // FormDto를 dto로 받아준다 ModelAttribute -> 전송되어지는걸 받는 역할
        log.info("FormDto dto.name = " + dto.getName());
        log.info("FormDto dto.isTrueOrFalse = " + dto.isTrueOrFalse());
        List<String> hobbies = dto.getHobbies();
        for (String hobby : hobbies) {
            log.info("dto.hobby = " + hobby);
        }
        log.info("Language = " + dto.getLanguage());
        log.info("Country = " + dto.getCountry());
        return "/formTest/form";
    }

    @ModelAttribute("hobbies")      // hobbies라는 이름으로 보낸다
    private Map<String, String> favorite(){
        Map<String, String> map = new HashMap<>();
        map.put("movie", "영화보기");
        map.put("music", "음악듣기");
        map.put("running", "런닝하기");
//        model.addAttribute("hobbies", map); 이 생략이 되어있음
        return map;     // ModelAttribute 가 model에 넣어주기까지 한다 (이 컨트롤러 안에서만)
    }
}
