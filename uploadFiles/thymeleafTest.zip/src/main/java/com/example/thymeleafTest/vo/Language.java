package com.example.thymeleafTest.vo;


import lombok.Getter;

@Getter
public enum Language {  // 규칙이 내재된 상수의 집합
    JAVA("자바"),
    C("C"),
    CPP("C++"),
    PYTHON("파이썬");

    private final String description;

    Language(String description) {
        this.description = description;
    }
}
