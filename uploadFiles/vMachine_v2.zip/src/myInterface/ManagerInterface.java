package myInterface;

public interface ManagerInterface {
    // 1.메뉴등록
    void enterMenu();
    // 2.메뉴삭제
    void deleteMenu();
    // 3.메뉴수정
    void updateMenu();
    // 4.재고등록
    void enterStock();
}