package myInterface;

public interface UserInterface {
    //1.동전투입
    void insertCoin();
    //2.잔돈반환
    void returnCoin();
    //3.메뉴선택
    void choiceMenu();
}
