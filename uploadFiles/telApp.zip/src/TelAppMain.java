import db.DBConn;
import dto.TelDto;
import service.TelBookService;
import view.UserView;

import java.sql.Connection;
import java.util.Scanner;

//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class TelAppMain {
    public static void main(String[] args) {

//        Connection conn = DBConn.getConnection();
        TelBookService service = new TelBookService();
        UserView userView = new UserView();

        Scanner sc = new Scanner(System.in);
        int ch = 0;
        while (true){
            do {
                System.out.println("1. 입력 2. 수정 3. 삭제 4. 전체출력 5. 아이디검색 6. 종료");
                System.out.println("=====================================================");
                ch = sc.nextInt();
            } while (ch < 0 || ch > 6);

            switch (ch) {
                case 1:
                    try {
                        userView.insert();
                    } catch (Exception e) {
                        throw new RuntimeException(e);
                    }

//                    int result;
//                    System.out.println("1.입력");   테스트문
//                    TelDto dto = new TelDto();
//                    dto.setName("우가연");
//                    dto.setAge(23);
//                    dto.setAddress("Fff");
//                    dto.setTelNum("010-6666-6666");
//                    result = service.insertData(dto);
                    break;
                case 2:
                    userView.update();
                    break;
                case 3:
                    userView.delete();
                    break;
                case 4:
                    userView.searchAll();
                    break;
                case 5:
                    userView.searchOne();
                    break;
                case 6:
                    DBConn.close();
                    System.exit(0);

            }
        }
    }
}