package com.example.pcRoom.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;

@Entity
public class Users {

    @Id
    @Column(nullable = false, length = 20)
    private String  userId;

    @Column(nullable = false, length = 10)
    private String name;

    @Column(nullable = false)
    private String password;

    private int money;
    @Column(nullable = false)
    private String status; //관리자 , 일반
}
