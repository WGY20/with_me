package com.example.pcRoom.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@ToString
@AllArgsConstructor
@NoArgsConstructor
public class UserDto {

    private String  userId;
    private String name;
    private String password;
    private String passwordCheck;
    private int money;
    private String status; //관리자 , 일반
}
